/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finallalithapeetam;

import java.io.DataInputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

/**
 *
 * @author SANSI
 */
public class Server {
    
    public static void main(String[]args) throws IOException
    {
        try
        {
     ServerSocket ss = new ServerSocket(8080);
     Socket s =  ss.accept();
     Socket s1= ss.accept();
     Socket s2= ss.accept();
     Socket s3= ss.accept();
    // Socket s2 = ss.accept();
     
        DataInputStream dis = new   DataInputStream (s.getInputStream());
        DataInputStream dis1 = new   DataInputStream (s1.getInputStream());
         // DataInputStream dis2 = new   DataInputStream (s2.getInputStream());
        String Name =(String)dis.readUTF();
        String Gothram =(String)dis.readUTF();
        String Date =(String)dis.readUTF();
        String Mobile =(String)dis.readUTF();
        String Price =(String)dis.readUTF();
        String Pooja =(String)dis.readUTF();
        String VastraSamarp =(String)dis.readUTF();
        
        
        String Name1 = (String)dis1.readUTF();
        String Gothram1 =(String)dis1.readUTF();
        String Date1 =(String)dis1.readUTF();
        String Mobile1 =(String)dis1.readUTF();
        String Price1 =(String)dis1.readUTF();
        String Pooja1 =(String)dis1.readUTF();
        String VastraSamarp1 =(String)dis1.readUTF();
        
        
        System.out.println(Name);
        System.out.println(Gothram);
        System.out.println(Date);
        System.out.println(Mobile);
        System.out.println(Price);
        System.out.println(Pooja);
        System.out.println(VastraSamarp);
            
        System.out.println(Name1);
        System.out.println(Gothram1);
        System.out.println(Date1);
        System.out.println(Mobile1);
        System.out.println(Price1);
        System.out.println(Pooja1);
        System.out.println(VastraSamarp1);
       
       // dis.close();     
        //dis1.close();
       
        s.close();
        s1.close();
        
        
         Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
              Connection connection= DriverManager.getConnection("jdbc:ucanaccess://C:\\Users\\SANSI\\Documents\\Data.accdb");
              System.out.println("Connected Successfully");
              //Crating PreparedStatement object
              PreparedStatement preparedStatement=connection.prepareStatement("insert into Lalithadevi(Name,Gothram,Date,Mobile,Price,Pooja,Vastra_Samarpana) values(?,?,?,?,?,?,?)");
              //Setting values for Each Parameter
              preparedStatement.setString(1,Name);
              preparedStatement.setString(2,Gothram);
              preparedStatement.setString(3,Date);
              preparedStatement.setString(4,Mobile);
              preparedStatement.setString(5,Price);
              preparedStatement.setString(6,Pooja);
              preparedStatement.setString(7,VastraSamarp);
 

              //Executing Query
              preparedStatement.executeUpdate();
              System.out.println("data inserted successfully");
        
        
             
         Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
              Connection connection1= DriverManager.getConnection("jdbc:ucanaccess://C:\\Users\\SANSI\\Documents\\Data.accdb");
              System.out.println("Connected Successfully");
              //Crating PreparedStatement object
              PreparedStatement preparedStatement1=connection1.prepareStatement("insert into Manidweepam(Name,Gothram,Date,Mobile,Price,Pooja,Vastra_Samarpana) values(?,?,?,?,?,?,?)");
              //Setting values for Each Parameter
              preparedStatement1.setString(1,Name1);
              preparedStatement1.setString(2,Gothram1);
              preparedStatement1.setString(3,Date1);
              preparedStatement1.setString(4,Mobile1);
              preparedStatement1.setString(5,Price1);
              preparedStatement1.setString(6,Pooja1);
              preparedStatement1.setString(7,VastraSamarp1);
 

              //Executing Query
              preparedStatement1.executeUpdate();
              System.out.println("data inserted successfully");
        
              
        
        
        
        }
        catch(Exception e){
            System.out.println(e);
        }
    }
}
